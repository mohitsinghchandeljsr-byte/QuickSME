@echo off
:: SME Tally Portable Launcher
title SME Tally - Portable Edition
color 0A
echo.
echo ============================================================================
echo              SME TALLY ACCOUNTING SOFTWARE
echo ============================================================================
echo.
echo [INFO] Starting SME Tally...
echo [INFO] Open browser and go to: http://localhost:5000
echo.
echo [INFO] Press Ctrl+C to stop the server
echo ============================================================================
echo.
node dist\index.js
echo.
echo [INFO] Server stopped.
pause
